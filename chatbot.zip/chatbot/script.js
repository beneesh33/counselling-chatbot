$(document).ready(function () {
    // Handle login validation
    $('#login-btn').click(function () {
        const username = $('#username').val().trim();
        const password = $('#password').val().trim();

        // Simple validation: username pattern and default password check
        const usernamePattern = /^urk22cs118[0-9]$|^urk22cs1190$/;
        if (usernamePattern.test(username) && password === 'password') {
            // Hide login form and show chatbot
            $('#login-container').hide();
            $('#chat-container').show();  // Show the chat interface
        } else {
            // Show error message
            $('#login-error').show();
        }
    });

    // Function to send message
    $('#send-btn').click(function () {
        const userMessage = $('#user-input').val().trim().toLowerCase();
        if (userMessage) {
            displayMessage(userMessage, "user");
            $('#user-input').val('');  // Clear the input field

            // Send the message to the server
            $.ajax({
                url: '/api/greeting',
                type: 'POST',
                contentType: 'application/json',
                data: JSON.stringify({ message: userMessage }),
                success: function (response) {
                    displayMessage(response.response, "bot");
                },
                error: function () {
                    displayMessage("Error in communication.", "bot");
                }
            });
        }
    });

    // Function to display messages in the chatbox
    function displayMessage(message, sender) {
        const messageClass = sender === "user" ? "user-message" : "bot-message";
        $('#chat-box').append('<div class="' + messageClass + '">' + message + '</div>');
        $('#chat-box').scrollTop($('#chat-box')[0].scrollHeight); // Auto scroll to bottom
    }
});
