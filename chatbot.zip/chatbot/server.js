const express = require('express');
const mongoose = require('mongoose');
const path = require('path');
const bodyParser = require('body-parser');

const app = express();
app.use(express.static(__dirname));
app.use(express.urlencoded({ extended: true }));  // Serve static files (HTML, CSS, JS)

// Connect to MongoDB
mongoose.connect('mongodb://localhost:27017/greetingsDB');

// Greeting schema and model
const greetingSchema = new mongoose.Schema({
    message: String
});

const Greeting = mongoose.model('Greeting', greetingSchema);

// Serve the HTML file
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'index.html'));
});

// Handle greeting message
app.post('/api/greeting', (req, res) => {
    const userMessage = req.body.message;

    // Save greeting to the database
    const greeting = new Greeting({ message: userMessage });
    greeting.save()
        .then(() => {
            // Respond with a bot reply
            let botResponse = `Hello! You said: "${userMessage}"`;
            res.json({ response: botResponse });
        })
        .catch(err => {
            console.error('Error saving message:', err);
            res.status(500).json({ response: 'Failed to save message.' });
        });
});

// Start the server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server is running on port ${PORT}`);
});
